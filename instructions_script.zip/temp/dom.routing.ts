import { NgModule } from '@angular/core';
import { RouterModule, Routes, CanActivate } from '@angular/router';

{{import}}

const routes: Routes = [
  {{routes}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DomRoutingModule { }
