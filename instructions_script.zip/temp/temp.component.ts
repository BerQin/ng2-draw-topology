import { Component } from '@angular/core';
@Component({
  selector: 'app-{{component}}',
  templateUrl: './{{component}}.component.html',
  styles: []
})

export class CDom{{component}}Component {
  {{code}}
}
