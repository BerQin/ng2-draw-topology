import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LibModule } from '../components/lib.module';

import { DomRoutingModule } from './dom.routing';

{{import}}

@NgModule({
  imports: [
    CommonModule,
    LibModule,
    DomRoutingModule,
    {{imports}}
  ],
  declarations: [
    {{declarations}}
  ]
})
export class DomsModule {}