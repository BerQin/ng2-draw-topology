const fs = require('fs');
const fle = require('./files');
const path = require('path');
const MD = require('marked');
const YFM = require('yaml-front-matter');
const wrench = require('wrench');

const componentTs = String(fs.readFileSync(path.resolve(__dirname, '../temp/temp.component.ts')));
const routes = String(fs.readFileSync(path.resolve(__dirname, '../temp/dom.routing.ts')));

const domc = {
  creatDomSrc: function (rootSrc, rootSrcArr) {
    let importStr = '';
    let importsStr = '';
    let declarationsStr = '';
    let routesStr = '';

    rootSrcArr.forEach(item => {
      importStr += `import { CDom${item.name}Component } from './${item.name}/${item.name}.component';\n`;

      declarationsStr += `CDom${item.name}Component,\n`;
      
      routesStr += `{
        path: '${item.name}',
        component: CDom${item.name}Component,
      },\n`;
    });
    const moduleText = String(fs.readFileSync(path.resolve(__dirname, '../temp/dom.module.ts')));
    const moduleT = moduleText.replace(/{{import}}/g, importStr).replace(/{{imports}}/g, importsStr).replace(/{{declarations}}/g, declarationsStr);

    const routesT = routes.replace(/{{import}}/g, importStr).replace(/{{routes}}/g, routesStr);

    fle.write(`${rootSrc}/doms.module.ts`, moduleT);
    fle.write(`${rootSrc}/dom.routing.ts`, routesT);
  },
  readDomMd: function(src, domRoot, name){
    const doc = baseInfo(fs.readFileSync(src), path.join(domRoot, name), name);
    console.log(doc);
    creatBox(doc);
    creatComponentHtml(doc);
    creatComponentTs(doc);
    return doc;
  }
}

function baseInfo(file, path, name) {
  const meta = YFM.loadFront(file);
  const content = meta.__content;
  delete meta.__content;
  return {
    meta   : meta,
    path   : path,
    name   : name,
    content: MD(content),
    raw    : content,
    stringContent : String(file)
  }
}

function creatBox(docObj) {
  wrench.mkdirSyncRecursive(docObj.path);
}

function creatComponentHtml(docObj) {
  fle.write(`${docObj.path}/${docObj.name}.component.html`, docObj.content);
}

function creatComponentTs(docObj) {
  const code = docObj.stringContent.match(/\/\/ star[\d|\D|\r\n|\n]{0,}\/\/ end/g);
  console.log(code);
  const comTs = componentTs.replace(/{{component}}/g, docObj.name).replace(/{{code}}/g, code && code.length ? code[code.length - 1] : '');
  fle.write(`${docObj.path}/${docObj.name}.component.ts`, comTs);
}

module.exports =  domc;