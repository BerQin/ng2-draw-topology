var fs = require('fs');
var colorStyle = require('./colors');

const fileChange = {
  copyFile: function(src, dist) {
    fs.writeFileSync(dist, fs.readFileSync(src));
  },
  write: function(path, txt) {
    fs.writeFile(path, txt,'utf8', function (err) {
      if (err) {
         return false;
      } else {
         console.log(colorStyle.green, `${path} 写入成功`);
      }
    });
  }
}

module.exports =  fileChange;