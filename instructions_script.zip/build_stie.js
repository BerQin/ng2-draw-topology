const fs = require('fs');
const path = require('path');
const wrench = require('wrench');
const watch = require('watch')

const fileC = require('./utils/files');
const colorStyle = require('./utils/colors');
const domC = require('./utils/dom');

// 处理命令参数
const target = process.argv[2];
const sTarget = target ? target.split(':') : [];

// 创建src项目文件
const showCasePath = path.resolve(__dirname, '../src');

if (!sTarget[0]) {
  wrench.rmdirSyncRecursive(`${showCasePath}`, true);
  wrench.copyDirSyncRecursive(path.resolve(__dirname, '_src'), `${showCasePath}`);
} else {
  wrench.rmdirSyncRecursive(`${showCasePath}/app/${sTarget[0]}`, true);
}
// 读取lib文件夹
const showCaseTargetPath = `${showCasePath}/app/`;
const RootComponts = path.join(showCaseTargetPath, 'components')
const RootDoms = path.join(showCaseTargetPath, 'doms')
const rootPath = path.resolve(__dirname, '../projects/lib');
const rootDir = fs.readdirSync(rootPath);

let pass = false;

let DomArr = [];

rootDir.forEach(componentName => {
  if (sTarget[0] && componentName !== sTarget[0]) {
    return;
  }
  // 通过
  pass = true;

  //创建componts文件夹
  if (!fs.existsSync(RootComponts)) {
    fs.mkdirSync(RootComponts);
  }

  if (componentName === 'style' || componentName === 'core'  ) {
    return;
  }
  // 得到路径
  const showCaseComponentPath = path.join(RootComponts, componentName);
  const componentDirPath = path.join(rootPath, componentName);

  if (fs.statSync(componentDirPath).isDirectory()) {
    // 创建src->${components}文件夹
    wrench.copyDirSyncRecursive(`${componentDirPath}`, `${showCaseComponentPath}`);

    // 处理components->${component}->dec.ts文件
    // 创建Dom文件夹 RootDoms
    if (!fs.existsSync(RootDoms)) {
      fs.mkdirSync(RootDoms);
    }
    if (fs.existsSync(componentDirPath)) {
      const demoDir = fs.readdirSync(componentDirPath);
      demoDir.forEach(demo => {
        const demoMarkDownSrc = path.join(componentDirPath, demo);
        if (/.md$/.test(demo)) {
          DomArr.push(domC.readDomMd(demoMarkDownSrc, RootDoms, componentName));
        }
      });
    }
  } else if (/.ts$/.test(componentDirPath)) {
    fileC.copyFile(componentDirPath, `${showCaseComponentPath}`);
  }
});

domC.creatDomSrc(RootDoms, DomArr);

!pass && console.error(colorStyle.red, `ERROR:  ${sTarget[0]} 文件夹不存在！\n`);

// 检测watch
if (sTarget[1] === 'watch') {
  watch.watchTree(rootPath, function (f, curr, prev) {
    if (typeof f == "object" && prev === null && curr === null) {
      console.log(colorStyle.green, `START: satrt watching...`)
    } else if (prev === null) {
      const path = f.split('projects\\lib');
      if (fs.statSync(f).isDirectory()) {
        wrench.copyDirSyncRecursive(f, `${RootComponts}${path[1]}`);
      } else {
        fileC.copyFile(f, `${RootComponts}${path[1]}`);
      }
      console.log(colorStyle.green, `CREAT: ${f} success`);
    } else if (curr.nlink === 0) {
      const path = f.split('projects\\lib');
      try {
        if (fs.statSync(`${RootComponts}${path[1]}`).isDirectory()) {
          wrench.rmdirSyncRecursive(`${RootComponts}${path[1]}`, true);
          console.log(colorStyle.green, `REMOVE: ${f} success`);
        } else {
          fs.unlink(`${RootComponts}${path[1]}`, function () {
            console.log(colorStyle.green, `REMOVE: ${f} success`);
          });
        }
      } catch (e) {
        // 重复的删除文件
      }
    } else {
      const path = f.split('projects\\lib');
      if (/.md$/.test(f)) {
        domC.readDomMd(f, RootDoms);
      } else {
        fs.writeFileSync(`${RootComponts}${path[1]}`, fs.readFileSync(f));
        console.log(colorStyle.green, `COPY: ${f} success`);
      }
    }
  });
}